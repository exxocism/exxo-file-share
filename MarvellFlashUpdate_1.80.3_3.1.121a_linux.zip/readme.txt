AtlFlashUpdate Tool

Description
=======================================================================
AtlFlashUpdate is a tool for updating firmware on AQC100, AQC108, AQC107, AQN100, AQN108, and AQN107

System Requirements
=======================================================================
Windows 10 64-bit
Windows 10 32-bit

Package contents
=======================================================================
atlflashupdate.exe - main executable, FW update
aqnicnvm64.sys - maintenance driver for interaction with NIC of x64 platforms
aqnicnvm86.sys - maintenance driver for interaction with NIC of x86 platforms
updatedata.xml - configuration file with update information
*.clx - firmware files, which will be burned to the NIC memory

Overview
=======================================================================
This document describes how to use the AtlFlashUpdate Tool to update firmware on Aquantia Network Adapters.

Usage
=======================================================================
Interactive mode:
  1) Unzip archive with tool to your hard drive
  2) Open Command line(CMD) and change working directory to extracted folder
  3) Execute "atlflashupdate" at this command line window
  4) Enter number of chosen card and press Enter

Silent mode:
  1) Unzip archive with tool to your hard drive
  2) Open Command line(CMD) and change working directory to extracted folder
  3) Execute "atlflashupdate -s" at this command line window

Rollback Firmware
  1) Execute "atlflashupdate -r" at this command line window
  2) Select the adapter number
  3) Original firmware will be restored.

Help message:
  1) Unzip archive with tool to your hard drive
  2) Open Command line(CMD) and change working directory to extracted folder
  3) Execute "atlflashupdate -h" at this command line window

Supported devices
=======================================================================

NIC, TB3 dongles, and TB3 docking stations
  Aquantia AQtion 10G Pro NIC
  Aquantia AQtion 10G Gaming NIC
  Aquantia AQtion 5G Pro NIC
  Aquantia AQtion SFP+ NIC
  Gigabyte GC-AQC107
  Promise SANLink3 N1
  QNAP QXG-10G1T
  QNA-T310G1S
  QNA-T310G1T
  Sonnet Solo10G SFP+ Thunderbolt 3
  Sonnet Technologies Solo 10G Thunderbolt 3

Example updating a NIC with 3.1.58 firmware to 3.1.109
======================================================

1. Open CMD Window as Admin
Microsoft Windows [Version 10.0.17763.437]
(c) 2018 Microsoft Corporation. All rights reserved. 

2. Go to folder that has the files extracted

C:\WINDOWS\system32>cd\AtlFlashUpdate

3. Run the executable program atlflashupdate


c:\MarvellFlashUpdate_1.5.0_3.1.100>atlflashupdate.exe
Aquantia AQtion Firmware Update Tool [Version 1.5.0]

*** Important notice ***
Update utility is only supported for certain systems.
Please refer README file for supported systems.

Proceed with update? (y/n): y
__________________________________________________________________________________________________________
No  Name                                    Firmware  Update status       Device         MAC address
__________________________________________________________________________________________________________
1   Aquantia AQtion 10Gbit Network Adapter  3.1.58    Available: 3.1.109  07B1-00011D6A  00:17:B6:00:5E:F3
__________________________________________________________________________________________________________

*** Important notice ***
The network connection may be dropped during the update process.
Please complete all network activity before updating.

Enter adapter number or 'q' for quit without update
>1

===
+ Adapter: Aquantia AQtion 10Gbit Network Adapter
|-- HWID:  VEN_1D6A&DEV_07B1&SUBSYS_00011D6A
|-- Backing up... [OK]
|-- Updating... [OK]
|-- New firmware version: 3.1.109
|-- Trying to reload firmware... [OK]
|-- Restarting device driver... [OK]
===


Firmware update finished!

Press any key...

c:\MarvellFlashUpdate_1.5.0_3.1.100>atlflashupdate.exe
Aquantia AQtion Firmware Update Tool [Version 1.5.0]

*** Important notice ***
Update utility is only supported for certain systems.
Please refer README file for supported systems.

Proceed with update? (y/n): y
_____________________________________________________________________________________________________
No  Name                                    Firmware  Update status  Device         MAC address
_____________________________________________________________________________________________________
1   Aquantia AQtion 10Gbit Network Adapter  3.1.109   Not required   07B1-00011D6A  00:17:B6:00:5E:F3
_____________________________________________________________________________________________________

No adapters can be updated

Press any key...

c:\MarvellFlashUpdate_1.5.0_3.1.100>



Example restoring previous firmware from 3.1.109 to 3.1.58
=======================================================================

c:\MarvellFlashUpdate_1.5.0_3.1.100>atlflashupdate.exe -r
Aquantia AQtion Firmware Update Tool [Version 1.5.0]

*** Important notice ***
Update utility is only supported for certain systems.
Please refer README file for supported systems.

Proceed with update? (y/n): y
_________________________________________________________________________________________________________
No  Name                                    Firmware  Rollback           Device         MAC address
_________________________________________________________________________________________________________
1   Aquantia AQtion 10Gbit Network Adapter  3.1.109   Available: 3.1.58  07B1-00011D6A  00:17:B6:00:5E:F3
_________________________________________________________________________________________________________

Please select an adapter to restore previous firmware version:

Enter adapter number or 'q' to quit
>1
This will restore adapter's firmware to the previous version.
  Current version:      3.1.109
  Previous version:     3.1.58
[WARNING] This is an experimental feature which may not work correctly.
  Please ONLY use if absolutely necessary, e.g. network adapter not functional after firmware update.
Please confirm firmware rollback operation (y/n): y
Backing up... [OK]
Performing firmware rollback on adapter 'Aquantia AQtion 10Gbit Network Adapter'...
Restarting device driver... [OK]
Firmware rollback finished!

Press any key...

c:\MarvellFlashUpdate_1.5.0_3.1.100>
